#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <cctype> // Include the cctype header for tolower() function

// Define the Course structure
struct Course {
    std::string courseNumber;
    std::string courseTitle;
    std::vector<std::string> prerequisites;
};

// Function to load data from the file into the data structure
void loadDataStructure(std::vector<Course>& courses) {
    // Clear existing data
    courses.clear();

    // Add new course information
    courses.push_back({"CSCI100", "Introduction to Computer Science", {}});
    courses.push_back({"CSCI101", "Introduction to Programming in C++", {"CSCI100"}});
    courses.push_back({"CSCI200", "Data Structures", {"CSCI101"}});
    courses.push_back({"CSCI301", "Advanced Programming in C++", {"CSCI101"}});
    courses.push_back({"MATH201", "Discrete Mathematics", {}});
    courses.push_back({"CSCI300", "Introduction to Algorithms", {"CSCI200", "MATH201"}});
    courses.push_back({"CSCI350", "Operating Systems", {"CSCI300"}});
    courses.push_back({"CSCI400", "Large Software Development", {"CSCI301", "CSCI350"}});
}

// Function to print a list of courses in alphanumeric order
void printCourseList(const std::vector<Course>& courses) {
    // Sort courses based on course number as integers
    std::vector<Course> sortedCourses = courses;
    std::sort(sortedCourses.begin(), sortedCourses.end(), [](const Course& a, const Course& b) {
        // Convert course numbers to integers for comparison
        int courseNumberA = std::stoi(a.courseNumber.substr(4)); // Assuming course numbers start with "CSCI"
        int courseNumberB = std::stoi(b.courseNumber.substr(4));
        return courseNumberA < courseNumberB;
    });

    // Print the sorted list
    std::cout << "Here is a sample schedule:" << std::endl;
    for (const Course& course : sortedCourses) {
        std::cout << course.courseNumber << ", " << course.courseTitle << std::endl;
    }
}

// Function to print course information (case-insensitive)
void printCourseInformation(const std::vector<Course>& courses, const std::string& courseNumber) {
    // Convert the input course number to lowercase for case-insensitive comparison
    std::string courseNumberLower = courseNumber;
    std::transform(courseNumberLower.begin(), courseNumberLower.end(), courseNumberLower.begin(), ::tolower);

    // Find the course based on the provided course number (case-insensitive)
    auto it = std::find_if(courses.begin(), courses.end(), [&courseNumberLower](const Course& course) {
        std::string courseNumberInData = course.courseNumber;
        std::transform(courseNumberInData.begin(), courseNumberInData.end(), courseNumberInData.begin(), ::tolower);
        return courseNumberInData == courseNumberLower;
    });

    // Check if the course was found
    if (it != courses.end()) {
        // Print course information
        std::cout << it->courseNumber << ", " << it->courseTitle << std::endl;

        // Print prerequisites
        if (!it->prerequisites.empty()) {
            std::cout << "Prerequisites: ";
            for (const std::string& prerequisite : it->prerequisites) {
                std::cout << prerequisite << ", ";
            }
            std::cout << std::endl;
        }
    } else {
        std::cout << "Course not found." << std::endl;
    }
}

int main() {
    // Vector to store courses
    std::vector<Course> courses;

    int choice;
    std::string courseNumber;
    do {
        std::cout << "Welcome to the course planner." << std::endl;
        std::cout << "1. Load Data Structure." << std::endl;
        std::cout << "2. Print Course List." << std::endl;
        std::cout << "3. Print Course." << std::endl;
        std::cout << "9. Exit" << std::endl;

        std::cout << "What would you like to do? ";
        std::cin >> choice;

        // Exit the loop if choice is greater than 4
        if (choice > 3) {
            std::cout << "Thank you for using the course planner!" << std::endl;
            break;
        }

        switch (choice) {
            case 1:
                loadDataStructure(courses);
                break;
            case 2:
                printCourseList(courses);
                break;
            case 3:
                std::cout << "What course do you want to know about? ";
                std::cin >> courseNumber;
                printCourseInformation(courses, courseNumber);
                break;
            default:
                std::cout << choice << " is not a valid option." << std::endl;
                break;
        }
    } while (true); // Use true in the while condition for an infinite loop

    return 0;
}
