/*
 * main.h
 *
 *  Created on: Dec 17, 2023
 *      Author: 0migu
 */

#ifndef MAIN_H_
#define MAIN_H_

class main {
public:
	main();
	virtual ~main();
};

#endif /* MAIN_H_ */
